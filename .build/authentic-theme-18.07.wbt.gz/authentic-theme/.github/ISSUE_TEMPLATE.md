Before posting an issue, please search through README.md and closed/opened issues to make sure that the answer to your questions hasn't been answered/discussed already.

Please make sure that you have latest theme (18.07) and Webmin (1.801) versions installed.

Provide the following information:
* What is your server-side OS and its version?
* What is your client-side OS, browser and its versions?
* What are the steps to reproduce the issue
